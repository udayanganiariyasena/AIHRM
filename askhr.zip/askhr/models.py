from djongo import models
from django.contrib.auth.models import User


class Chat(models.Model):
    user_input = models.CharField(max_length=255)
    bot_response = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"User: {self.user_input} | Bot: {self.bot_response}"