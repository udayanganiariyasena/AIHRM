from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render
from .models import Chat

@csrf_exempt
def chatbot(request):
    if request.method == 'POST':
        user_input = request.POST.get('message', '').strip().lower()

        # Simple keyword-based responses
        if 'hello' in user_input or 'hi' in user_input:
            response = "Hello! How can I assist you today?"
        elif 'leave' in user_input:
            response = "You can apply for leave through the Leave Management section."
        elif 'task' in user_input:
            response = "Check your tasks in the Task Management section."
        elif 'hr' in user_input:
            response = "For HR-related queries, please contact HR directly."
        else:
            response = "I'm sorry, I didn't understand that. Can you please rephrase?"

        # Save the chat to the database (optional)
        Chat.objects.create(user_input=user_input, bot_response=response)

        return JsonResponse({'response': response})
    return JsonResponse({'error': 'Invalid request method'}, status=400)

def chatbot_interface(request):
    return render(request, 'askhr/askhrchatbot.html')